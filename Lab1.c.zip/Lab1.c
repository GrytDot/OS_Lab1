#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <signal.h>

sem_t empty;
sem_t full;
int cnt = 0;
int N;
long BUFFER_SIZE;
long TimeInterval;

void Sig_exit(int signum)
{
    printf(" Received Ctrl-C. Cleaning up and exiting...\n");
    sem_destroy(&empty);
    sem_destroy(&full);
    exit(0);
}

void *producer(void *data)
{
    int *Buffer = (int *)data;
    int tmp;
    while (1)
    {
        sem_wait(&empty);
        if (cnt < BUFFER_SIZE)
        {
            Buffer[cnt] = cnt;
            tmp = cnt;
            tmp = tmp + 1;
            cnt = tmp;
            printf("Produced: %d\n\n", cnt);
        }
        else
        {
            printf("Buffer is full, waiting...\n");
        }
        sem_post(&full);
        sleep(TimeInterval);
    }
}

void *consumer(void *data)
{
    int *Buffer = (int *)data;
    while (1)
    {
        sem_wait(&full);
        if (cnt > 0)
        {
            printf("Consumed: %d\n\n", cnt);
        }
        sem_post(&empty);
        sleep(TimeInterval);
    }
}

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: %s <N> <BUFFER_SIZE> <TimeInterval>\n", argv[0]);
        return 1;
    }

    N = atoi(argv[1]);
    BUFFER_SIZE = strtol(argv[2], NULL, 10);
    TimeInterval = strtol(argv[3], NULL, 10);
    int Buffer[BUFFER_SIZE];

    long i;
    int ret;
    pthread_t tid_p;
    pthread_t tid_c[N];

    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);

    signal(SIGINT, Sig_exit);

    ret = pthread_create(&tid_p, NULL, producer, (void *)Buffer);
    if (ret)
    {
        fprintf(stderr, "failed to create producer thread\n");
        return 1; // Exit with an error code
    }

    for (i = 0; i < N; i++)
    {
        ret = pthread_create(&tid_c[i], NULL, consumer, (void *)Buffer);
        if (ret)
        {
            fprintf(stderr, "pthread_create() failed! [%d]\n", ret);
            return 1; // Exit with an error code
        }
    }

    pthread_join(tid_p, NULL);
    for (i = 0; i < N; i++)
    {
        pthread_join(tid_c[i], NULL);
    }
}